import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import BottomNav from "./Bottom/BottomNav";
import logo from "./assets/logo1.png";
import Login from "./Login/Login";
function App() {
  return (
    <>
      <Login/>
      <BottomNav />
    </>
  );
}

export default App;
